//
//  ViewController.swift
//  NotificationDemo
//
//  Created by MAC2 on 19/11/18.
//  Copyright © 2018 MAC2. All rights reserved.
//

import UIKit
import UserNotifications

class ViewController: UIViewController
{
    func initNotificationSetUpCheck()
    {
        UNUserNotificationCenter.current().requestAuthorization(options: [.alert]) { (success, erroe) in
            if success
            {
                print("Success")
            }
            else
            {
                print("Error")
            }
        }
    }
    override func viewDidLoad()
    {
        super.viewDidLoad()
        initNotificationSetUpCheck()
        // Do any additional setup after loading the view, typically from a nib.
    }

    @IBAction func btnNotify(_ sender: Any)
    {
        let notification = UNMutableNotificationContent()
        notification.title = "Demo"
        notification.subtitle = "Demo of notification"
        notification.body = "This is local notifiation"
        let notificationTrigger = UNTimeIntervalNotificationTrigger(timeInterval: 60, repeats: true)
        let request = UNNotificationRequest(identifier: "notification", content: notification, trigger: notificationTrigger)
        UNUserNotificationCenter.current().add(request,withCompletionHandler: nil)
    }
}

